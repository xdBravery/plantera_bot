import discord
import random
from discord.ext import commands
import asyncio
import os
import json

bot = commands.Bot(command_prefix="!")

@bot.event
async def on_connect():
 print ("Bot is online!")

@bot.command()
async def test(ctx):
  await ctx.send ("Hello.")

@bot.command()
async def invite(ctx):
  await ctx.send ("https://bit.ly/3F5YK6p")

@bot.command()
async def sus(ctx):
  await ctx.send ("HOLY SHIT DID YOU JUST SAY THE WORD SUS???😳1?/1😱//1😳/1111!!!! Wait, you don't know what it is from?😳😳😳Let 👆give you a brief r/history. 📚📚📚👨‍🚀If you didn't r/knowyourshit, the r/term sus(suspicious) is a saying from the r/popular r/game r/AmongUs. Among us is so fun😔 👉👈, don't insult it, every youtuber and streamer says so!!!!!!!11 Corpses voice is so deep am i right or am i right😳😳????? I mean Mr beast and Dream play and pull big 🧠 1000000000000 iq moves in their videos..... YOU WERE THE IMPOSTER.... ඞ ඞ ඞ Get it because you don't know what sus means? r/stupidquestions r/youranidot r/stupidcuck. I CAnT BELEeVE YOUU dont KNoW WHT SUS MeaNS?/??!??!?!!🖕🖕🖕🖕🖕 Man why do i have to r/explain this to a r/idiot🤪🤪🤪📚📚📚... Sus is a GREAT WORD from a GREAT VIDEO GAME. in class, YOU CAN PLAY IT ON YOUR PHONE😜😜😜😜😜😜**??!?!?** such a masterpiece... FOR THE GREAT PRICE OF FREE!!!11!💰💰🤑🤑🤑🤑😜😜😜💰💰 It can also mean gay 😳😳😳😳")

@bot.command()
async def fortnite(ctx):
  await ctx.send ("https://i1.sndcdn.com/artworks-FBNUtixUjOTiGdE1-kUbEiA-t500x500.jpg")

@bot.command()
async def info(ctx):
  await ctx.send ("Hello! I am the Discord Bot Plantera Jr. I was coded in Python by user xPlantera#0001 and I only exist because he wanted his own custom discord bot.")

@bot.command()
async def games(ctx):
  await ctx.send ("Here are a few games I reccomend for you to play/buy: Borderlands 3, Dying Light, Terraria, and DOOM Eternal")

@bot.command()
async def ideas(ctx):
 await ctx.send ("Leave your suggestions or ideas for this bot in the suggestions channel.")

@bot.command(pass_context=True)
async def coinflip(ctx):
    variable = [
        "Heads!",
        "Tails!",]
    await ctx.send (random.choice(variable))

@bot.command(pass_context=True)
async def cf(ctx):
    variable = [
        "Heads!",
        "Tails!",]
    await ctx.send (random.choice(variable))


@bot.command(pass_context=True)
async def kanyequote(ctx):
    variable = [
        "I feel like i'm too busy writing history to be in it.",

        "I refuse to accept other people's ideas of happiness for me, as if there's a one size fits all standard for happiness.",

        "People always say that you can’t please everybody. I think that’s a cop-out. Why not attempt it? ‘Cause think of all the people you will please if you try",

        "My goal, if I was going to do art, fine art, would have been to become Picasso or greater. That always sounds so funny to people, comparing yourself to someone in the past that has done so much, and in your life you're not even allowed to think that you can do as much. That's a mentality that suppresses humanity.",
       
        "I hate when I’m on a flight and I wake up with a water bottle next to me like oh great now I gotta be responsible for this water bottle.",

        "I HAVE A FUCKING LIGHT SHOW DUMB ASS, IT’S NOT CALLED GLOW IN THE DARK FOR NO REASON SQUID BRAINS!",

        "I don’t even listen to rap. My apartment is too nice to listen to rap in.",

        "Just imagine if I woke up one day and I was whack. What would I do then?",

        "You should only believe about 90 percent of what I say. As a matter of fact, don’t even believe anything that I’m saying at all.",
        
        "I am God’s vessel. But my greatest pain in life is that I will never be able to see myself perform live.",

      
         ]
    await ctx.send (random.choice(variable))

@bot.command(pass_context=True)
async def playlist(ctx):
     variable = [ 
        "https://open.spotify.com/playlist/4Hl5ICnViCW9mrn2ZK4e9F?si=3202f6d8c69d4057",]
     await ctx.send (random.choice(variable))

@bot.command(pass_context=True)
async def pl(ctx):
    variable = [
        "https://open.spotify.com/playlist/4Hl5ICnViCW9mrn2ZK4e9F?si=3202f6d8c69d4057"]
    await ctx.send (random.choice(variable))

@bot.command()
async def plantera(ctx):
 await ctx.send(file=discord.File("plantera for ascii.png"))

@bot.command()
async def yt(ctx):
    embed=discord.Embed(title="xPlantera's YouTube", url="https://www.youtube.com/channel/UCvIJM5qgJGHFN-4FVg4zvWw", description="This is a link to xPlantera's YouTube Channel.", color=0xFFC0CB)
    await ctx.send(embed=embed)

@bot.command()
async def code(ctx):
    embed=discord.Embed(title="Plantera Jr's Official Code", url="https://replit.com/@xPlantera/My-first-bot#main.py", description="This is a link to Plantera Jr's Code", color=0xFFC0CB)
    await ctx.send(embed=embed)

@bot.command()
async def youtube(ctx):
    embed=discord.Embed(title="xPlantera's YouTube", url="https://www.youtube.com/watch?v=uJihqk7XIXY", description="This is a link to xPlantera's YouTube Channel.", color=0xFFC0CB)
    await ctx.send(embed=embed)

with open("users.json", "ab+") as ab:
    ab.close()
    f = open('users.json','r+')
    f.readline()
    if os.stat("users.json").st_size == 0:
      f.write("{}")
      f.close()
    else:
      pass
 
with open('users.json', 'r') as f:
  users = json.load(f)
 
@bot.event    
async def on_message(message):
    if message.author.bot == False:
        with open('users.json', 'r') as f:
            users = json.load(f)
        await add_experience(users, message.author)
        await level_up(users, message.author, message)
        with open('users.json', 'w') as f:
            json.dump(users, f)
            await bot.process_commands(message)
 
async def add_experience(users, user):
  if not f'{user.id}' in users:
        users[f'{user.id}'] = {}
        users[f'{user.id}']['experience'] = 0
        users[f'{user.id}']['level'] = 0
  users[f'{user.id}']['experience'] += 6
  print(f"{users[f'{user.id}']['level']}")
 
async def level_up(users, user, message):
  experience = users[f'{user.id}']["experience"]
  lvl_start = users[f'{user.id}']["level"]
  lvl_end = int(experience ** (1 / 50))
  if lvl_start < lvl_end:
    await message.channel.send(f':tada: {user.mention} has reached level {lvl_end}. Congrats! :tada:')
    users[f'{user.id}']["level"] = lvl_end
 
@bot.command()
async def rank(ctx, member: discord.Member = None):
  if member == None:
    userlvl = users[f'{ctx.author.id}']['level']
    await ctx.send(f'{ctx.author.mention} You are at level {userlvl}!')
  else:
    userlvl2 = users[f'{member.id}']['level']
    await ctx.send(f'{member.mention} is at level {userlvl2}!')






token = os.environ['token']

bot.run(token)